const input = document.getElementById("input");
const send = document.getElementById("send");
const chat = document.getElementById("chatArea");
const typing = document.getElementById("typing");
const welcome = document.getElementById("welcome");

const replies = [
  "Interesting!",
  "Tell me more.",
  "I understand.",
  "Good question.",
  "Let’s explore that."
];

function addMessage(text, type) {
  const div = document.createElement("div");
  div.className = "msg " + type;
  div.innerText = text;
  chat.appendChild(div);
  chat.scrollTop = chat.scrollHeight;
}

function sendMessage(msgText = null) {
  let msg = msgText || input.value.trim();
  if (!msg) return;

  welcome.style.display = "none";

  addMessage(msg, "user");
  input.value = "";

  typing.style.display = "flex";

  setTimeout(() => {
    typing.style.display = "none";
    let reply = replies[Math.floor(Math.random() * replies.length)];
    addMessage(reply, "ai");
  }, 1200);
}

send.onclick = () => sendMessage();

input.addEventListener("keydown", (e) => {
  if (e.key === "Enter") {
    e.preventDefault();
    sendMessage();
  }
});

input.addEventListener("input", () => {
  input.style.height = "auto";
  input.style.height = input.scrollHeight + "px";
});

function newChat() {
  chat.innerHTML = "";
  welcome.style.display = "block";
}